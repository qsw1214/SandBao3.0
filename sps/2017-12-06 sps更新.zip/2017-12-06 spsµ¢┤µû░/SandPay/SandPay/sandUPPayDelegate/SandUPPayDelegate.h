//
//  SandUPPayDelegate.h
//  SandPay
//
//  Created by blue sky on 2016/12/29.
//  Copyright © 2016年 PengLin. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol SandUPPayDelegate

- (void)upPayResult:(NSString*)result;

@end
