//
//  SandUPPayDelegate.m
//  SandPay
//
//  Created by blue sky on 2016/12/29.
//  Copyright © 2016年 PengLin. All rights reserved.
//

#import "SandUPPayDelegate.h"

@implementation SandUPPayDelegate

@end
