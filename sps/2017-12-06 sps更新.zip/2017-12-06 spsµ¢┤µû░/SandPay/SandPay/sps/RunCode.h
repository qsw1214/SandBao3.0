//
//  retcode.h
//  sps2-dev
//
//  Created by Rick Xing on 6/24/13.
//  Copyright (c) 2013 Rick Xing. All rights reserved.
//

#ifndef RunCode_h
#define RunCode_h

#define RunCode_Ok                      0x00000000
#define RunCode_Network_Error           0x00000001
#define RunCode_PayCore_Error           0x00000002
#define RunCode_User_Cancel             0x00000003





#endif
