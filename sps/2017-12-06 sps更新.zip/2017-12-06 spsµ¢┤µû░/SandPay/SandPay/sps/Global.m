//
//  Global.m
//  sps2-dev
//
//  Created by Rick Xing on 7/2/13.
//  Copyright (c) 2013 Rick Xing. All rights reserved.
//

#import "Global.h"

static id BridgeDelegate;
static id CheckoutDelegate;


@interface Global ()
@end

@implementation Global
GET_AND_SET_METHOD_ID(BridgeDelegate)
GET_AND_SET_METHOD_ID(CheckoutDelegate)



@end
