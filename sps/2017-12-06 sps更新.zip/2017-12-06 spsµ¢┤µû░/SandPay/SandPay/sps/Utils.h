//
//  Utils.h
//  TestPlat
//
//  Created by Xing Rick on 12-4-12.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "stdrfx.h"

@interface Utils : NSObject

+ (NSString *)byte2hex:(BYTE *)byte Length:(int)len;
+ (int)hex2byte:(NSString *)hex Byte:(BYTE *)byte;


@end
