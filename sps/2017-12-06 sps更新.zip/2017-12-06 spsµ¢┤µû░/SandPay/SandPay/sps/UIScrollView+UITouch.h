//
//  UIScrollView+UITouch.h
//  SandLife
//
//  Created by WeiWei on 16/10/17.
//  Copyright © 2016年 Sand. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScrollView (UITouch)

@end
