//
//  Str2Data.h
//  ItestXC
//
//  Created by Rick on 16/6/21.
//  Copyright © 2016年 SAND. All rights reserved.
//

#ifndef Str2Data_H
#define Str2Data_H

#import <Foundation/Foundation.h>

#include "xstring.h"
using namespace sz;

NSData * str2data(NSString * str);
NSString * data2str(NSData * data);

NSData * xstr2data(XString str);
XString data2xstr(NSData * data, int offset, int len);

#endif
