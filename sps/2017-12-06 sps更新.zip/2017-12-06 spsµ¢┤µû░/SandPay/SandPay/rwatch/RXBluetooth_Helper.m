//
//  RXBluetooth_Helper.m
//  ItestXC
//
//  Created by Rick Xing on 16/6/1.
//  Copyright © 2016年 SAND. All rights reserved.
//

#import "RXBluetooth_Helper.h"
#import "CoreBluetooth/CoreBluetooth.h"

RXBluetooth_Helper * btHelper;

@implementation RXBluetooth_Helper

@synthesize BT_UUID_SVC;
@synthesize BT_UUID_TX;
@synthesize BT_UUID_RX;

@synthesize Peripheral;

@synthesize Characteristic_TX;
@synthesize Characteristic_RX;

@synthesize RecvFinished;
@synthesize RecvData;

@end

