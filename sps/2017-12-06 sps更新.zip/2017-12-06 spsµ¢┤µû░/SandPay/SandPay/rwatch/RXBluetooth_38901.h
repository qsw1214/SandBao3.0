//
//  RXBluetooth_38901.h
//  ItestXC
//
//  Created by Rick Xing on 16/6/1.
//  Copyright © 2016年 SAND. All rights reserved.
//

#ifndef RXBLUETOOTH_38901_H
#define RXBLUETOOTH_38901_H

bool bt_trans_with_protocol(unsigned char * send_data, int send_data_len, unsigned char * recv_data, int * recv_data_len, int timeout_ms);

#endif
