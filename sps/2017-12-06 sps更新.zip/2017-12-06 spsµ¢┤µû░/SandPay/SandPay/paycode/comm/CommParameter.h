//
//  CommParameter.h
//  collectionTreasure
//
//  Created by blue sky on 15/7/24.
//  Copyright (c) 2015年 sand. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommParameter : NSObject
{
    
}

@property (nonatomic, strong) NSString *userId;
@property (nonatomic, strong) NSString *sid;



//实例构造检查静态实例是否为nil
+ (CommParameter *) sharedInstance;

@end
