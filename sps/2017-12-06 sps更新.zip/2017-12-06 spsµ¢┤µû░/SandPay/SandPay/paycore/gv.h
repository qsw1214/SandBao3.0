//
//  gv.h
//  sps2-dev
//
//  Created by Rick Xing on 6/25/13.
//  Copyright (c) 2013 Rick Xing. All rights reserved.
//

#ifndef __GV_H__
#define __GV_H__

#include "RXSandPayCore.h"

#include "xstring.h"
using namespace sz;


#define PayToolsMAX  64

extern RXSandPayCore payCore;

extern int RunCode;

extern int payTools_Index;
extern RXSandPayCore::PayToolPath ptPaths[PayToolsMAX];
extern XString payTools_Text[PayToolsMAX];

extern XString CardMedia_1B;
extern XString CardSerial_4B;
extern XString CardPlat_1B;
extern XString CardIssuer_3B;
extern XString CardNo_8B;
extern XString CardExpiry_4B;
extern XString CardRechargeSN_8B;
extern int CardBalance;
extern int AccountBalance;


#endif
