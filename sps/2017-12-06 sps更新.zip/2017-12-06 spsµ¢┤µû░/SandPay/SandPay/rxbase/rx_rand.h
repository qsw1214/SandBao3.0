/*
 * Random
 *
 * Copyright (c) 2011 Rick Xing <xingpub@gmail.com>
 */

#ifndef RX_RAND_H
#define RX_RAND_H

void STDCALL rx_Rand_Seed(void);
int STDCALL rx_Rand_Gen(int begin_num, int end_num);

#endif
