/*
 * appenv
 *
 * Copyright (c) 2011 Rick Xing <xingpub@gmail.com>
 */

#ifndef __APPENV_RX__
#define __APPENV_RX__

#ifndef NULL
#define NULL	0
#endif

#ifndef TRUE
#define TRUE	1
#endif

#ifndef FALSE
#define FALSE	0
#endif

//typedef signed char			BOOL;
typedef unsigned char		BYTE;
typedef unsigned short		WORD;
typedef unsigned long		DWORD;
typedef int                 INT;
typedef unsigned int        UINT;

#define STDCALL

#include <string.h>

#ifndef __OPTIMIZE__
# define NSLog(...) NSLog(__VA_ARGS__)
#else
# define NSLog(...) {}
#endif




#endif
